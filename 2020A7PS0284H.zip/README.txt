| Name             | ID            |
| ---------------- | ------------- |
| Akshat Oke       | 2020A7PS0284H |
| Sankalp Kulkarni | 2020A7PS1097H |
| Chirag Gadia     | 2020A7PS1721H |
| Shreyas Dixit    | 2020A7PS2079H |
| Aaditya Rathi    | 2020A7PS2191H |

# Mini-C

A compiler for a subset of C, made using lex and yacc.

See README.md for details.
