import time
start = time.time()
for i in range(40000):
    for j in range(3000):
        pass
end = time.time()
print(end - start)
