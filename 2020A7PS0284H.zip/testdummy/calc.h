typedef enum
{
  typeCon,
  typeId,
  typeOpr
} nodeEnum;

// constants
typedef struct
{
  nodeEnum type;
  int value;
} conNodeType;

// identifiers
typedef struct
{
  nodeEnum type;
  int i; // subscript to index array
} idNodeType;

// operators
typedef struct
{
  nodeEnum type;
  int oper;
  int nops;
  union nodeTypeTag *op[1];
} oprNodeType;

typedef union nodeTypeTag
{
  nodeEnum type;
  conNodeType con;
  idNodeType id;
  oprNodeType opr;
} nodeType;
extern int sym[26];