#ifndef __BACKEND
#define __BACKEND
#include "ir.h"
#include "irgen.h"

void backend(Node *astRootNode, char *sourceFileName);

#endif
