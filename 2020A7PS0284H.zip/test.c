#include <stdio.h>
void main()
{
  int a = 0x34;
  int b = 0b10101;
  int c = 013;
  printf("c=%d", c);
}