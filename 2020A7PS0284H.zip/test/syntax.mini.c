float main()
{
  float h = 4, k = 2;
  h = k + 4.2;
  printf("h is actually %f\n", h);
  return h;
}