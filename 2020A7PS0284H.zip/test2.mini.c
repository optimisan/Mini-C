// d = a[3];
// #include <stdio.h>
// int *get()
// {
//   return {1, 2, 3};
// }
// float a = 3;

// char g[][][8][4] = 'k', k = 8;
// int g[] = {3}, k = {6};
// return 5;
int main(int i)
{
  // char a[] = {"61", "42"};
  char a[][3] = {{'a'}};
  a[2][4] = '3';
  for (int i = 0; i < 2; i++)
  {
    main(main(2));
    // a[2][3] = a[1][3];
  }
  return -1;
  /*dsfsdf*/
  int as = 4 % "asd";
  // a[1] = '4';
  // b = a(2);
  // void data = b;
  // printf("%s\n", data[1]);
}
