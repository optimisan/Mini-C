#ifndef __TOKEN
#define __TOKEN
char *tokenStr(int token);
void printToken(int token);
#endif